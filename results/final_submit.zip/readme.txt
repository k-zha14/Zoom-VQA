runtime per video [s] : 0.1758
CPU[1] / GPU[0] : 0
Extra Data [1] / No Extra Data [0] : 1
Other description : The elapsed time is measured on a V100 GPU card. Considering our method includes two seperate branches, the runtime per video is calculated by taking the maximum value.
